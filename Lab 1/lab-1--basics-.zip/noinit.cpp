#include <iostream>

int main() {
  int x = 3;
  return x;
}